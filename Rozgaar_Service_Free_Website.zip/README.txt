ROZGAAR SERVICE - FREE STARTER WEBSITE

1. Open index.html in your browser to preview the website.
2. Before publishing, open index.html in Notepad.
3. Find: const adminNumber='92XXXXXXXXXX';
4. Replace it with your WhatsApp number including country code, digits only.
   Example format: 923001234567 (example only; use your own number).
5. Replace the sample job listings with real, verified vacancies.
6. To put it online for free, use Google Sites for a no-code version, or a static hosting service that permits your intended use. Check the host's terms. This HTML page is a starter front-end; it does not have a database, employer accounts, or automatic job publishing.
